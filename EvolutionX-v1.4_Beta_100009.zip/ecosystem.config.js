// For PM2 Users Who Are Hosting it on VPS.
// Feel Safe To Delete this file.

module.exports = {
    apps: [{
        name: "Evolution X",
        script: "node index.js"
    }]
}